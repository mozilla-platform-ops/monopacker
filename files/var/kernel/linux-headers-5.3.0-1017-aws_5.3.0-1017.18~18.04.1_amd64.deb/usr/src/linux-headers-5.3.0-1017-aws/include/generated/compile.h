/* This file is auto generated, version 18~18.04.1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#18~18.04.1 SMP Mon May 4 12:37:21 UTC 2020"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ip-172-31-12-75"
#define LINUX_COMPILER "gcc version 7.5.0 (Ubuntu 7.5.0-3ubuntu1~18.04)"
