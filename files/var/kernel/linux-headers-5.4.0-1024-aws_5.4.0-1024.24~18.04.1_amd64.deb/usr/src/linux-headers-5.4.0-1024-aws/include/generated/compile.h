/* This file is auto generated, version 24~18.04.1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#24~18.04.1 SMP Tue Sep 15 18:06:03 UTC 2020"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "dustin-kernel-build"
#define LINUX_COMPILER "gcc version 7.5.0 (Ubuntu 7.5.0-3ubuntu1~18.04)"
