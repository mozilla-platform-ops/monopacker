/* This file is auto generated, version 58 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#58 SMP Wed Dec 4 16:05:47 UTC 2019"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ip-172-31-14-163"
#define LINUX_COMPILER "gcc version 7.4.0 (Ubuntu 7.4.0-1ubuntu1~18.04.1)"
